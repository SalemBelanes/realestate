-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Ven 13 Février 2015 à 20:13
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `symfony`
--

-- --------------------------------------------------------

--
-- Structure de la table `annonce`
--

CREATE TABLE IF NOT EXISTS `annonce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `date_creation` date NOT NULL,
  `date_echeance` date NOT NULL,
  `ville` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rue` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `etat` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code_postal` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `prix` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre_piece` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre_like` int(11) NOT NULL,
  `nombre_dislike` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Contenu de la table `annonce`
--

INSERT INTO `annonce` (`id`, `titre`, `description`, `date_creation`, `date_echeance`, `ville`, `rue`, `etat`, `code_postal`, `prix`, `telephone`, `type`, `nombre_piece`, `nombre_like`, `nombre_dislike`) VALUES
(1, 'fgfg', 'fgfgf', '2010-01-01', '2010-01-01', 'azaz', 'azaz', 'azaz', '0123', '1212', '1212121', 'ffgfgfg', 'fgfgf', 3, 3),
(2, 'said', 'fgfgf', '2010-01-01', '2010-01-01', 'azaz', 'azaz', 'azaz', '0123', '1212', '1212121', 'ffgfgfg', 'fgfgf', 3, 3),
(3, 'salem', 'fgfgf', '2010-01-01', '2010-01-01', 'azaz', 'azaz', 'azaz', '0123', '1212', '1212121', 'ffgfgfg', 'fgfgf', 3, 3),
(4, 'raouf', 'fgfgf', '2010-01-01', '2010-01-01', 'azaz', 'azaz', 'azaz', '0123', '1212', '1212121', 'ffgfgfg', 'fgfgf', 3, 3),
(5, 'dzdz', 'zfeff', '2010-01-01', '2010-01-01', 'efe', 'fezfze', 'fezfez', '0123', '1212', '1212121', 'ffgfgfg', 'fgfgf', 4, 4),
(6, 'dzdz', 'zfeff', '2010-01-01', '2010-01-01', 'efe', 'fezfze', 'fezfez', '0123', '1212', '1212121', 'ffgfgfg', 'fgfgf', 4, 4),
(7, 'dzdz', 'zfeff', '2010-01-01', '2010-01-01', 'efe', 'fezfze', 'fezfez', '0123', '1212', '1212121', 'ffgfgfg', 'fgfgf', 4, 4),
(8, 'vbvb', 'vbvbv', '2010-01-01', '2011-01-01', 'cvcbfb', 'vbvb', 'vbvb', 'vbb', '22', '22', '22', '2', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `medias`
--

CREATE TABLE IF NOT EXISTS `medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annonce_id` int(11) DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_157EAAB78805AB2F` (`annonce_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Contenu de la table `medias`
--

INSERT INTO `medias` (`id`, `annonce_id`, `url`, `alt`) VALUES
(1, NULL, '/Image1.png', 'Image1.png'),
(2, 2, '/said.png', 'said.png'),
(3, 3, '/uploads/annonce_/medias/salem.png', 'salem.png'),
(4, 4, '/uploads/annonce_4/medias/raouf.png', 'raouf.png'),
(5, 6, '/uploads/annonce_6/medias/sa.jpg', 'sa.jpg'),
(6, 6, '/uploads/annonce_6/medias/raouf.png', 'raouf.png'),
(7, 6, '/uploads/annonce_6/medias/raouf.png', 'raouf.png'),
(8, 7, '/uploads/annonce_7/medias/sa.jpg', 'sa.jpg'),
(9, 7, '/uploads/annonce_7/medias/raouf.png', 'raouf.png'),
(10, 7, '/uploads/annonce_7/medias/sa1.jpg', 'sa1.jpg'),
(11, 8, '/uploads/annonce_8/medias/sa1.jpg', 'sa1.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `modele`
--

CREATE TABLE IF NOT EXISTS `modele` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Libelle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Payes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prenom` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `prenom`) VALUES
(1, 'said', 'dah'),
(2, 'salem', 'bel');

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `medias`
--
ALTER TABLE `medias`
  ADD CONSTRAINT `FK_157EAAB78805AB2F` FOREIGN KEY (`annonce_id`) REFERENCES `annonce` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
